//
//  WZBatchRequest.swift
//  TestBatchRequest
//
//  Created by andy on 2022/11/30.
//

import Foundation

protocol WZBatchRequestDelegate {
    func batchRequestDidSuccess(batchRequest: WZBatchRequest)
    func batchRequestDidFailure(error: Error)
}

class WZBatchRequest {
    let requestArray: [any WZRequestable]
    var delegate: WZBatchRequestDelegate
    
    init(requestArray: [any WZRequestable], delegate: WZBatchRequestDelegate) {
        self.requestArray = requestArray
        self.delegate = delegate
    }
    
    func send() {
        //循环发送requestArray中的请求，然后全部请求成功后调用batchRequestDidSuccess，否则调用batchRequestDidFailure
    }
}
