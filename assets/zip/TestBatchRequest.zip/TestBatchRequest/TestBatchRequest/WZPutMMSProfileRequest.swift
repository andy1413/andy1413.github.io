//
//  WZPutMMSProfileRequest.swift
//  TestBatchRequest
//
//  Created by andy on 2022/11/30.
//

import Foundation

class WZPutMMSProfileRequest: WZRequestable {
    var subURL = "/api/v1/monitoring/v1/profile"
    var method = "put"
    var delegate: WZRequestDelegate?

    typealias Body = WZCPPProfile
    var body: Body
    typealias ResponseBody = WZCPPProfile
    var responseBody: ResponseBody?

    init(body: Body, delegate: WZRequestDelegate? = nil) {
        self.body = body
        self.delegate = delegate
    }
}
