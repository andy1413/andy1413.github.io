//
//  ViewController.swift
//  TestDiscreteTypeNetwork
//
//  Created by andy on 2022/11/29.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        let profile = WZCPPProfile(hms_id: "111", devices: ["222"])
        let request1 = WZPutCPPProfileRequest(body: profile)
        let request2 = WZPutMMSProfileRequest(body: profile)
        let batchRequest = WZBatchRequest(requestArray: [request1, request2], delegate: self)
        batchRequest.send()
    }
}

extension ViewController: WZBatchRequestDelegate {
    func batchRequestDidSuccess(batchRequest: WZBatchRequest) {
        let requests = batchRequest.requestArray
        if let request = requests[0] as? WZPutCPPProfileRequest {
            print(request.responseBody)
        } else if let request = requests[1] as? WZPutMMSProfileRequest {
            print(request.responseBody)
        }
    }

    func batchRequestDidFailure(error: Error) {
        print(error)
    }
}
