//
//  WZPutProfileRequest.swift
//  TestBatchRequest
//
//  Created by andy on 2022/11/30.
//

import Foundation

struct WZCPPProfile: Codable {
    var hms_id: String
    var devices: [String]
}

class WZPutCPPProfileRequest: WZRequestable {
    var subURL = "/api/v1/hms/v2/profile"
    var method = "put"
    var delegate: WZRequestDelegate?
    
    typealias Body = WZCPPProfile
    var body: Body
    typealias ResponseBody = WZCPPProfile
    var responseBody: ResponseBody?

    init(body: Body, delegate: WZRequestDelegate? = nil) {
        self.body = body
        self.delegate = delegate
    }
}
