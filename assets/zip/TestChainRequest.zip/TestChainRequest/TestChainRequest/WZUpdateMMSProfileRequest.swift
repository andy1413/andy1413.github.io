//
//  WZGetAlarmStatusRequest.swift
//  TestChainRequest
//
//  Created by andy on 2022/11/30.
//

import Foundation

struct WZUpdateMMSProfileResponse: Codable {}

class WZUpdateMMSProfileRequest: WZRequestable {
    var subURL = "/api/v1/monitoring/v1/profile"
    var method = "put"
    var delegate: WZRequestDelegate?

    typealias Body = WZMMSProfile
    var body: Body
    typealias ResponseBody = WZUpdateMMSProfileResponse
    var responseBody: ResponseBody?

    init(body: Body, delegate: WZRequestDelegate? = nil) {
        self.body = body
        self.delegate = delegate
    }
}
