//
//  ViewController.swift
//  TestChainRequest
//
//  Created by andy on 2022/11/30.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let request1 = WZGetCPPProfileRequest(body: .init())
        let chainRequest = WZChainRequest(requestArray: [request1], delegate: self)
        chainRequest.send()
    }
}

extension ViewController: WZChainRequestDelegate {
    func baseRequestDidSuccess(chainRequest: WZChainRequest, baseRequest: some WZRequestable) {
        if let request = baseRequest as? WZGetCPPProfileRequest, let cppProfile = request.responseBody {
            
            let request2 = WZGetMMSProfileRequest(body: .init(hms_id: cppProfile.hms_id))
            chainRequest.add(request2)
        } else if let request = baseRequest as? WZGetMMSProfileRequest, var mmsProfile = request.responseBody {
            mmsProfile.devices = []
            let request3 = WZUpdateMMSProfileRequest(body: mmsProfile)
            chainRequest.add(request3)
        }
    }
    
    func chainRequestDidSuccess(chainRequest: WZChainRequest) {
        let requests = chainRequest.requestArray
        //可以统一处理所有链式请求的结果，也可以在每个request的回调中分别处理。
    }

    func chainRequestDidFailure(error: Error) {
        print(error)
    }
}
