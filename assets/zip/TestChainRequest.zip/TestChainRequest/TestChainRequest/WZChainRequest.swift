//
//  WZChainRequest.swift
//  TestChainRequest
//
//  Created by andy on 2022/11/30.
//

import Foundation

protocol WZChainRequestDelegate {
    func baseRequestDidSuccess(chainRequest: WZChainRequest, baseRequest: some WZRequestable)
    func chainRequestDidSuccess(chainRequest: WZChainRequest)
    func chainRequestDidFailure(error: Error)
}

class WZChainRequest {
    let requestArray: [any WZRequestable]
    var delegate: WZChainRequestDelegate?
    
    init(requestArray: [any WZRequestable], delegate: WZChainRequestDelegate) {
        self.requestArray = requestArray
        self.delegate = delegate
    }
    
    func add(_ request: any WZRequestable) {
        
    }
    
    func send() {
        //循环发送requestArray中的请求，然后全部请求成功后调用batchRequestDidSuccess，否则调用batchRequestDidFailure
    }
}
