//
//  WZGetMMSProfileRequest.swift
//  TestChainRequest
//
//  Created by andy on 2022/11/30.
//

import Foundation

struct WZGetMMSProfileRequestBody: Codable {
    var hms_id: String
}

struct WZMMSProfile: Codable {
    var hms_id: String
    var devices: [String]
    var setupCompleted: Bool
}

class WZGetMMSProfileRequest: WZRequestable {
    var subURL = "/api/v1/monitoring/v1/profile"
    var method = "get"
    var delegate: WZRequestDelegate?

    typealias Body = WZGetMMSProfileRequestBody
    var body: Body
    typealias ResponseBody = WZMMSProfile
    var responseBody: ResponseBody?

    init(body: Body, delegate: WZRequestDelegate? = nil) {
        self.body = body
        self.delegate = delegate
    }
}
