//
//  View2Controller.swift
//  TestDelegate
//
//  Created by andy on 2022/11/29.
//

import UIKit
protocol NetworkDelegate: AnyObject {
    func requestSuccess(_ request: BaseRequest)
    func requestFailure(error: Error)
}

class BaseRequest {
    weak var delegate: NetworkDelegate?
    var response: [AnyHashable: Any] = [:]
    
    func send() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.25) {
            self.response = [1:1]
            self.delegate?.requestSuccess(self)
        }
    }
}

class CPPProfileRequest: BaseRequest {
    
}

class View2Controller: UIViewController, NetworkDelegate {
    deinit {
        print("deinit")
    }
    
    func requestSuccess(_ request: BaseRequest) {
        print(request.response)
    }
    
    func requestFailure(error: Error) {
        print(error)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = .red
        let request = CPPProfileRequest()
        request.delegate = self
        request.send()
    }
}
