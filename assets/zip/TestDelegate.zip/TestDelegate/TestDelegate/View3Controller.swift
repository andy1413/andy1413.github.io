//
//  View3Controller.swift
//  TestDelegate
//
//  Created by andy on 2022/11/29.
//

import UIKit

class BlockBaseRequest {
    var response: [AnyHashable: Any] = [:]
    
    var successCallback: ((BlockBaseRequest) -> Void)?
    
    func send() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 4.25) {
            self.response = [1:1]
            self.successCallback?(self)
        }
    }
}

class CPPBlockProfileRequest: BlockBaseRequest {
    
}

class View3Controller: UIViewController {
    deinit {
        print("deinit")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = .red
        let request = CPPBlockProfileRequest()
        request.successCallback = { [weak self] request in
            guard let self = self else { return }
            print(request.response)
        }
        request.send()
    }
}
