//
//  ViewController.swift
//  TestDelegate
//
//  Created by andy on 2022/11/29.
//

import UIKit

class ViewController: UIViewController {
    
    @IBAction func buttonClick(_ sender: Any) {
        let view2C = View3Controller()
        self.navigationController?.pushViewController(view2C, animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = .gray
    }
}

