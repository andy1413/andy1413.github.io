//
//  WZCPPProfileRequest.swift
//  TestDiscreteTypeNetwork
//
//  Created by andy on 2022/11/30.
//

import Foundation

struct WZCPPProfileRequestBody: Codable {
    var hms_id: String
}

struct WZCPPProfile: Codable {
    var hms_id: String
    var devices: [String]
}

class WZCPPProfileRequest: WZRequestable {
    
    var subURL = "v1/hms/v2/profile"
    var method = "post"
    var delegate: WZRequestDelegate?

    typealias Body = WZCPPProfileRequestBody
    var body: Body
    typealias ResponseBody = WZCPPProfile
    var responseBody: ResponseBody?

    init(body: Body, delegate: WZRequestDelegate? = nil) {
        self.body = body
        self.delegate = delegate
    }
}
