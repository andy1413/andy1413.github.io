//
//  WZRequest.swift
//  TestDiscreteTypeNetwork
//
//  Created by andy on 2022/11/30.
//

import Foundation

protocol WZRequestable: AnyObject {
    var subURL: String { get }
    var method: String { get }

    associatedtype Body: Codable
    var body: Body { get set }
    var delegate: WZRequestDelegate? { get set }

    associatedtype ResponseBody: Codable
    var responseBody: ResponseBody? { get set }
}

extension WZRequestable {
    var params: [AnyHashable: Any] {
        //此处body模型转字典获取到params，这里暂时写死
        ["hms_id": "111"]
    }
    
    func send() {
        WZRequest.send(subURL: subURL, method: method, params: params) { responseDic in
            self.responseBody = WZCPPProfile(hms_id: "111", devices: ["222"]) as? ResponseBody
            delegate?.requestDidSuccess(self)
        } failure: { error in

        }
    }
}

protocol WZRequestDelegate: AnyObject {
    func requestDidSuccess(_ request: some WZRequestable)
    func requestDidFailure(_ error: Error)
}

struct WZRequest {
    static func send(subURL: String, method: String, params: [AnyHashable: Any], success: ([AnyHashable: Any]) -> Void, failure: (Error) -> Void) {

    }
}
