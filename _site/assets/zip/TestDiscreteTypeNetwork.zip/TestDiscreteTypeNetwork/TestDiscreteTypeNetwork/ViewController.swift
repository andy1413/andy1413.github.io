//
//  ViewController.swift
//  TestDiscreteTypeNetwork
//
//  Created by andy on 2022/11/29.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        //集约式Api调用方式
        WZRequest.send(subURL: "v1/hms/v2/profile", method: "post", params: ["hms_id": "1111"]) { response in
            print(response)
        } failure: { error in
            print(error)
        }

        //离散型Api调用方式
        let request = WZCPPProfileRequest(body: .init(hms_id: "1111"), delegate: self)
        request.send()
    }
}

extension ViewController: WZRequestDelegate {
    func requestDidSuccess(_ request: some WZRequestable) {
        print(request.responseBody)
    }

    func requestDidFailure(_ error: Error) {
        print(error)
    }
}
