//
//  ViewController.swift
//  TestHandyJSON
//
//  Created by andy on 2022/11/29.
//

import UIKit
import HandyJSON

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        struct Cat: HandyJSON {
            var id: Int = 1
            var color: String?
            var name: String?
            
            mutating func mapping(mapper: HelpingMapper) {
                mapper <<< id <-- "cat_id"
            }
        }

        let jsonString = "{\"cat_id\":1000,\"color\":\"black\",\"name\":\"cat\"}"

        if let cat = Cat.deserialize(from: jsonString) {
            print(cat)
        }
    }


}

